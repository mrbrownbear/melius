---
version: '1.0'
name: 'Melius Visual Identity'
description: 'A practical design contract for creating Melius product, marketing, editorial, and partner experiences.'
colors:
  black: '#0E0E0E'
  offblack: '#1A1616'
  off-white: '#FAFAFA'
  white: '#FFFFFF'
  orange: '#F04E23'
  graphite: '#3E3E3E'
  gray: '#676767'
  warm-gray: '#9C9996'
  ash: '#D9D9D9'
  yellow: '#FFF78B'
  amber: '#EA9E1A'
  lavender: '#C7ADFF'
  purple: '#A37AFF'
  periwinkle: '#B0BFE3'
  navy: '#4164B9'
  lime: '#E0E07B'
  olive: '#9D9D25'
typography:
  display:
    fontFamily: 'Reckless Standard'
    fontWeight: 400
    usage: 'Expressive headlines and large brand statements'
  interface:
    fontFamily: 'FG Futurist'
    fontWeight: 400
    usage: 'Sub-headlines, navigation, labels, and product-scale emphasis'
  body:
    fontFamily: 'Ease Standard'
    fontWeight: 400
    usage: 'Body copy, details, controls, and calls to action'
shape:
  card-radius: '0px'
  control-radius-small: '6px'
  control-radius-default: '8px'
  circle: '50%'
  pill: '9999px'
spacing:
  card-gap: '5px'
  card-padding: '15px'
  card-group-gap: '20px'
  section-spacing: '80px'
  page-gutter: 'max(3vw, 15px)'
components:
  card:
    radius: '{shape.card-radius}'
    padding: '{spacing.card-padding}'
    border: '1px solid rgba(185, 185, 185, 0.4)'
  button:
    radius: '{shape.control-radius-default}'
    duration: '200ms'
    easing: 'cubic-bezier(0.37, 0, 0.63, 1)'
motion:
  level: 'controlled'
  micro-duration: '200ms'
  standard-easing: 'cubic-bezier(0.37, 0, 0.63, 1)'
---

# Melius Design System

## Overview

Melius is a creative platform built around iteration. Its identity should feel
connected, responsive, spacious, and grounded in the product experience.

The visual system combines:

- A node-based mark that represents connected creative work.
- Expressive editorial typography paired with precise interface typography.
- A grounded black, off-white, and orange core palette.
- Sharp accents used for nodes, diagrams, generated imagery, and moments of
  emphasis.
- Spacious compositions that let prompts, outputs, imagery, and brand marks
  remain legible.

The system should bridge imagination and execution. It can feel vivid and in
motion, but it should never become noisy or ornamental for its own sake.

## Brand Principles

### Connected

Reference nodes, prompts, cursors, outputs, branching paths, and relationships.
The identity should suggest that every output can become a new starting point.

### Iterative

Show change, refinement, and multiplication rather than a single fixed result.
Sequences and systems are more characteristic of Melius than isolated
decorations.

### Spacious

Use negative space as an active part of the design. Important copy, imagery, and
marks need room to breathe.

### Direct

Use short, confident language. Connect an imagined result to an action or
outcome without over-explaining.

### Product-grounded

Brand expressions should feel related to the Melius creative workflow. Avoid
visual metaphors that could belong to any technology company.

## Logo

The approved logo assets are included in the `logo` folder:

- `melius-symbol.svg`
- `melius-wordmark.svg`
- `melius-horizontal-lockup.svg`
- `melius-vertical-lockup.svg`

### Symbol

Use the symbol for compact placements such as avatars, favicons, app icons, and
cursor-led moments.

### Wordmark

Use the wordmark when the Melius name must be read clearly without a larger
brand frame.

### Horizontal lockup

Use the horizontal lockup by default for headers, footers, press materials, and
partner layouts.

### Vertical lockup

Use the vertical lockup for centered brand moments and square-format
compositions.

### Logo rules

- Preserve the original proportions.
- Keep at least one symbol-height of clear space around the logo when possible.
- Use black on light surfaces and off-white on dark surfaces.
- Use orange only when the mark retains strong contrast.
- Do not stretch, rotate, outline, redraw, add shadows, or apply arbitrary
  gradients.
- Do not place the mark over visually busy imagery without a quiet field or
  sufficient contrast.

## Color

### Core palette

| Role      | Value     | Usage                                                |
| --------- | --------- | ---------------------------------------------------- |
| Black     | `#0E0E0E` | Primary dark text, marks, and high-contrast surfaces |
| Off-black | `#1A1616` | Warm dark backgrounds and immersive brand moments    |
| Off-white | `#FAFAFA` | Primary light background and reversed text           |
| White     | `#FFFFFF` | Elevated light surfaces and utility contrast         |
| Orange    | `#F04E23` | Primary accent, action, focus, and brand emphasis    |

Black, off-white, and orange carry the highest brand recognition. Orange should
lead actions and focal moments rather than fill every available surface.

### Neutral palette

| Role       | Value     | Usage                                |
| ---------- | --------- | ------------------------------------ |
| Graphite   | `#3E3E3E` | Dark secondary surfaces and text     |
| Gray       | `#676767` | Muted text and supporting UI         |
| Warm gray  | `#9C9996` | Quiet labels and neutral transitions |
| Gray light | `#B9B9B9` | Borders and subtle structure         |
| Ash        | `#D9D9D9` | Light supporting surfaces            |

For page borders, use `rgba(185, 185, 185, 0.4)` or the project token
`--color-gray-light-2-faded`.

### Accent palette

| Color      | Value     |
| ---------- | --------- |
| Yellow     | `#FFF78B` |
| Amber      | `#EA9E1A` |
| Lavender   | `#C7ADFF` |
| Purple     | `#A37AFF` |
| Periwinkle | `#B0BFE3` |
| Navy       | `#4164B9` |
| Lime       | `#E0E07B` |
| Olive      | `#9D9D25` |

Use accent colors sparingly for diagrams, nodes, charts, creative examples, and
generated imagery. They support the core palette; they do not replace it.

### Color rules

- Use color roles consistently instead of choosing accents arbitrarily.
- Maintain readable foreground and background contrast.
- Do not communicate status or meaning through color alone.
- Avoid low-contrast recoloring of the logo.
- Prefer luminous combinations with warm and cool depth over flat rainbow
  treatments.

## Typography

Melius uses three type families with distinct responsibilities. Do not collapse
them into one generic sans-serif system.

### Reckless Standard

Reckless Standard is the expressive display face.

- Use for large headlines and brand statements.
- Use regular weight by default.
- Keep line-height tight, generally `1`.
- Use restrained negative tracking for the largest style.
- Avoid using it for dense interface copy.

Primary implementation styles:

| Token   | Desktop size | Line height | Tracking  |
| ------- | ------------ | ----------- | --------- |
| `t-h-1` | `3.5rem`     | `1`         | `-0.02em` |
| `t-h-2` | `2.625rem`   | `1`         | Default   |
| `t-h-3` | `2.25rem`    | `1`         | Default   |
| `t-h-4` | `1.7rem`     | `1`         | Default   |

### FG Futurist

FG Futurist provides structure and a product-minded voice.

- Use for sub-headlines, navigation, labels, tags, and display metrics.
- Use regular weight.
- Keep line-height compact.
- Use tighter tracking at larger sizes.

Primary implementation styles include `t-h-1--sans` through `t-h-5--sans`,
`t-l-1`, `t-tag-usecase-1`, and `t-tag-usecase-2`.

### Ease Standard

Ease Standard is the utility and reading face.

- Use for body copy, descriptions, details, prompts, controls, and calls to
  action.
- Use regular weight for most copy and medium only when hierarchy requires it.
- Use body line-height around `1.2` to `1.4`.

Primary implementation styles:

| Token           | Desktop size | Line height | Tracking  |
| --------------- | ------------ | ----------- | --------- |
| `t-b-1`         | `1.1875rem`  | `1.4`       | `-0.04em` |
| `t-b-2`         | `0.85rem`    | `1.2`       | `-0.03em` |
| `t-b-3`         | `0.8rem`     | `1.2`       | `-0.03em` |
| `t-b-3-relaxed` | `0.75rem`    | `1.4`       | `-0.03em` |

### Responsive typography

Display type scales down at the `lg` and `sm` breakpoints. Preserve hierarchy
instead of forcing desktop sizes onto smaller screens. Body text should remain
readable and should not be reduced merely to make a layout fit.

The fonts are licensed assets and are not included in this public brand package.
Use properly licensed copies or approved fallbacks.

## Layout and Spacing

Melius layouts are content-led and responsive.

- Use `max(3vw, 15px)` as the adaptive page gutter.
- Use `80px` as the standard large section-spacing reference.
- Use `15px` for card padding in compact guideline-style systems.
- Use `5px` between closely related cards or panels.
- Use `20px` between larger card groups.
- Prefer grids for related visual systems and flexible compositions for
  editorial sections.
- Use full-bleed imagery intentionally; keep text within a readable container.
- Preserve generous negative space around hero statements and primary imagery.

Do not introduce near-duplicate spacing values when an existing token fits.

## Shape and Surfaces

Cards and content panels use square outer corners by default. Do not add
decorative card radius.

Rounded geometry is reserved for:

- Buttons and compact controls.
- Pills and tags when their function benefits from the form.
- Intentional circles such as ports, nodes, avatars, and indicators.
- Media whose art direction explicitly requires a shaped mask.

Surface hierarchy should come primarily from color, spacing, borders, imagery,
and composition rather than heavy shadow.

### Cards

- Default padding: `15px`.
- Default border: `1px solid rgba(185, 185, 185, 0.4)`.
- Default outer radius: `0`.
- Internal gap: `5px`.
- Group gap: `20px`.
- Avoid unnecessary nested borders.
- Keep media and content aligned to the same spacing logic.

### Borders

Use the shared gray-light border treatment for quiet structure. Strong white or
black borders should be reserved for high-contrast diagrams or states where the
edge itself carries meaning.

## Components

### Buttons

Buttons are compact, direct, and visibly interactive.

- Default transition duration: `200ms`.
- Default easing: `cubic-bezier(0.37, 0, 0.63, 1)`.
- Use orange for primary actions.
- Use black or off-black for strong neutral actions.
- Use white for actions on dark backgrounds where appropriate.
- Use a border treatment for secondary actions.
- Preserve visible focus states.
- Avoid hover effects that alter layout dimensions.

Typical control radii are `6px` and `8px`. Pills are intentional exceptions,
not the default shape for every control.

### Prompt input

The prompt is a core Melius product cue.

- Use a dark, high-contrast surface.
- Keep the lens mark, prompt text, and send action visually balanced.
- Reserve enough height for the longest animated prompt to avoid layout shift.
- Animate placeholder text without blocking user input.
- Stop decorative motion when reduced motion is requested.

### Navigation

- Keep labels short and scannable.
- Use orange for active emphasis when appropriate.
- Horizontal navigation below desktop should scroll without moving surrounding
  layout.
- Use edge masking to indicate overflow while preserving the page gutter.
- Keep navigation keyboard accessible and maintain visible focus.

### Color swatches

- Display the canonical hexadecimal value.
- Make interactive swatches keyboard accessible.
- When clicking copies a value, provide visible and screen-reader confirmation.
- Use an eyedropper or copy cursor only as a supporting cue, never as the sole
  indication of interactivity.

## Art Direction

Melius imagery shows the range and process of creation. It should feel vivid,
spacious, and slightly in motion.

### Subject families

- Lifestyle and scenes.
- Product and objects.
- Abstract generative states.

### Color

Let orange lead when color is the story, supported by cool blues, greens, or
neutrals. Avoid flat single-color scenes. The palette should feel luminous and
layered.

### Distortion

Use blur, scan lines, glow, or softened movement to suggest generation in
progress. Effects should add energy without obscuring the subject.

### Gradation

Use chromatic shifts, gradients, and edge fringing to create depth. The result
should sit between photography and illustration rather than feel like a filter
placed over an image.

### Image rules

- Preserve a clear subject or focal area.
- Use motion and distortion with restraint.
- Keep enough quiet space for copy when text overlays imagery.
- Avoid stock-like technology imagery and unrelated futuristic decoration.
- Do not use effects that make the generated work difficult to understand.

## Copy

Melius copy is concise, confident, and imaginative.

- Prefer active voice.
- Lead with the result, possibility, or action.
- Connect imagination to execution.
- Keep headlines short.
- Use product language such as prompt, node, output, branch, adjust, and refine
  when it fits naturally.
- Avoid generic AI superlatives, inflated claims, and long technical
  explanations.

Example tone:

> Exactly as you imagined.

## Motion

Motion should communicate generation, connection, and state change.

- Use approximately `200ms` for common interface transitions.
- Use `cubic-bezier(0.37, 0, 0.63, 1)` for balanced on-screen movement.
- Prefer transform and opacity for animated properties.
- Use restrained looping motion only for ambient or generative moments.
- Keep hover behavior focused on color, opacity, stroke, or small transforms.
- Avoid layout-shifting animation.
- Respect `prefers-reduced-motion`.
- Ensure animations remain interruptible and never block interaction.

Longer choreography may use GSAP or Motion when it communicates a meaningful
sequence. Do not add scroll animation merely because a section enters the
viewport.

## Accessibility

- Maintain WCAG AA contrast for text and controls.
- Preserve visible keyboard focus.
- Use semantic controls for interactive elements.
- Keep interactive targets large enough for touch.
- Provide alternative text for meaningful imagery.
- Do not rely on color, hover, or motion alone to communicate meaning.
- Reserve layout space for animated and asynchronous content.
- Respect reduced-motion preferences.
- Ensure content remains usable when fonts scale or text wraps.

## Do and Don't

### Do

- Use the approved logo assets.
- Build visual ideas from prompts, nodes, outputs, cursors, and branching paths.
- Use black, off-white, and orange as the recognizable core.
- Apply accents with clear roles and restraint.
- Keep compositions spacious.
- Keep copy direct.
- Reuse existing typography, spacing, color, and motion tokens.
- Test responsive layouts and interaction states.

### Don't

- Do not redraw, stretch, rotate, outline, or freely recolor the logo.
- Do not crowd layouts.
- Do not add unrelated ornaments.
- Do not mix arbitrary gradients into the core brand mark.
- Do not add decorative card radius.
- Do not introduce one-off colors or spacing values without a semantic need.
- Do not use motion that shifts layout or competes with the content.
- Do not make the brand feel generically technical.

## Implementation Tokens

The following CSS variables are canonical references in the Melius web project:

```css
--color-black: rgb(14, 14, 14);
--color-offblack: rgb(26, 22, 22);
--color-white: rgb(250, 250, 250);
--color-orange: rgb(240, 78, 35);

--color-gray-dark-3: rgb(62, 62, 62);
--color-gray: rgb(103, 103, 103);
--color-gray-light-1: rgb(156, 153, 150);
--color-gray-light-2: rgb(185, 185, 185);
--color-gray-light-2-faded: rgba(185, 185, 185, 0.4);
--color-gray-light-3: rgb(217, 217, 217);

--color-yellow: rgb(255, 247, 139);
--color-amber: rgb(234, 158, 26);
--color-lavender: rgb(199, 173, 255);
--color-purple: rgb(163, 122, 255);
--color-periwinkle: rgb(176, 191, 227);
--color-navy: rgb(65, 100, 185);
--color-lime: rgb(224, 224, 123);
--color-olive: rgb(157, 157, 37);

--font-reckless-standard: 'Reckless Standard', serif;
--font-fg-futurist: 'FG Futurist', sans-serif;
--font-ease-standard: 'Ease Standard', sans-serif;

--s-contain: max(3vw, 15px);
--s-section: 80px;
--ease-sin-in-out: cubic-bezier(0.37, 0, 0.63, 1);
```

For guideline-style card systems:

```css
--brand-guideline-border-color: var(--color-gray-light-2-faded);
--brand-guideline-card-padding: 15px;
--brand-guideline-card-gap: 5px;
--brand-guideline-card-group-gap: 20px;
```

## Package Contents

```text
melius-brand-assets.zip
├── DESIGN.md
└── logo
    ├── melius-horizontal-lockup.svg
    ├── melius-symbol.svg
    ├── melius-vertical-lockup.svg
    └── melius-wordmark.svg
```
